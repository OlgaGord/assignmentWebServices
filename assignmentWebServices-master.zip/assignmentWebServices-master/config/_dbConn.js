let dbConn = {
	host: "localhost",
	user: "username",
	password: "",
	connectionLimit: 5,
	database: "db"
};

module.exports = dbConn;
