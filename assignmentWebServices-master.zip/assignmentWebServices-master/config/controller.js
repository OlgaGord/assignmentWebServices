const obj = {
	json: false
};
module.exports = obj;
